package com.internship.virtual.internship;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VirtualInternshipApplication {

	public static void main(String[] args) {
		SpringApplication.run(VirtualInternshipApplication.class, args);
	}

}
